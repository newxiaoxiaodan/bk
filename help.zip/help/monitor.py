# -*- coding: utf-8 -*-
from ..base import ComponentAPI


class CollectionsMonitor(object):
    """Collections of monitor APIS"""

    def __init__(self, client):
        self.client = client

        self.list_alarm_instance = ComponentAPI(
            client=self.client, method='GET',
            path='/api/c/compapi{bk_api_ver}/monitor/list_alarm_instance/',
            description=u'获取告警列表'
        )
