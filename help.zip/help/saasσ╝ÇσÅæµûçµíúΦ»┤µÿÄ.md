# saas开发文档说明


### 1. 静态页面可参考或直接使用frontend中的文件
前端代码示例中使用了 MagicBox Vue 组件库，使用方式参考：
https://magicbox.bk.tencent.com/components_vue/2.0/example/index.html#/


### 2. Vue 与 Django Template 变量语法冲突的问题
由于 Vue 与 Django Template 的变量都使用了 {{ var }} 的格式，因此像以下混用时，会导致渲染异常
1.	<a href="{{ django_var }}">
2.	{{ vue_var }}
3.	</a>
解决方法：使用 Django Template 提供的忽略渲染语法，如下
4.	<a href="{{ django_var }}">
5.	{% verbatim %}
6.	{{ vue_var }}
7.	{% endverbatim %}
8.	</a>


### 3. 相关组件接口文档链接
请注意，以下为接口文档说明地址，而非实际接口调用地址
•	业务查询：https://paas.exam.bktencent.com/esb/api_docs/system/CC/search_business/
•	set查询：https://paas.exam.bktencent.com/esb/api_docs/system/CC/search_set/
•	模块查询：https://paas.exam.bktencent.com/esb/api_docs/system/CC/search_module/
•	监控查询：https://paas.exam.bktencent.com/esb/api_docs/system/MONITOR/list_alarm_instance/
•	根据模板ID创建任务：https://paas.exam.bktencent.com/esb/api_docs/system/SOPS/create_task/
•	开始执行任务：https://paas.exam.bktencent.com/esb/api_docs/system/SOPS/start_task/
•	查询任务状态：https://paas.exam.bktencent.com/esb/api_docs/system/SOPS/get_task_status/
4. 监控列表拉取接口说明
本次考试每个考生通过监控列表接口拉取 与exam-webserver进程，端口为考生准考证后五位 相关的所有告警, 其中拉取进程端口告警接口 可配置参数：
'alarm_type': 'proc_port'
在拉取的进程相关的告警后，可通过 match_dimension 中的display_name 和 nolisten 进行匹配， 具体参数规则请参考 告警列表


### 5. 标准运维任务执行说明：
标准运维任务执行为异步任务，当启动任务之后，需要通过[查询任务状态](https://paas.exam.bktencent.com/esb/api_docs/system/SOPS/get_task_status/
)
xlwt的使用
本次考试内容导出到excel文档要求通过python后台生成，建议采用python包xlwt来实现，导出excel基本使用方法如下
9.	import xlwt
10.	import io
11.	from django.http import HttpResponse
12.	def export(request):
13.	work_book = xlwt.Workbook(encoding='utf-8')
14.	work_sheet = work_book.add_sheet("sheet1")
15.	for index, head in enumerate(["col1","col2","col3"]):
16.	work_sheet.col(index).width = 256 * 20
17.	work_sheet.write(0, index, head)
18.	for row in [1,2,3]:
19.	for col, value in enumerate([4,5,6]):
20.	work_sheet.write(row, col, value)
21.	output = io.BytesIO()
22.	work_book.save(output)
23.	output.seek(0)
24.	response = HttpResponse(output.getvalue(),
25.	content_type='application/vnd.ms-excel')
26.	response[ 'Content-Disposition'] = 'attachment;filename="example.xls"'
27.	return response
生成文档如下：
 


###6. Ajax请求注意事项
因为测试环境和正式环境的app访问地址携带了/[t|o]/bk_app_id/前缀，故需要在ajax请求地址前固定添加以上前缀，所以若你使用的是开发框架
自带的模板渲染，需要在index.html的head部分增加以下内容（index.html中已经提前放好，直接去掉注释即可）：

```js
<script type="text/javascript">
	var app_code = "{{ APP_CODE }}";          // 在蓝鲸系统里面注册的"应用编码"
	var site_url = "{{ SITE_URL }}";          // app的url前缀,在ajax调用的时候，应该加上该前缀
	var remote_static_url = "{{ REMOTE_STATIC_URL }}";   //远程资源链接，403页面需要，不要删除
	var debug_mode = JSON.parse("{{ DEBUG }}");   // 是否调试模式
</script>
// 并且在发起ajax请求时，固定添加前缀site_url，比如：
<script type="text/javascript">
	$.ajax({
	url: site_url + 'business/',
	type: 'GET',
	data: {},
	success: function (res) {
		// do something
		}
	});
</script>
```

### 7. POST请求出现403(csrf验证失败)的解决方法
在页面中引入开发框架目录下的：static/js/csrftoken.js，且确保在jquery后面引入

```js
	<script src="{{ STATIC_URL }}js/csrftoken.js" type="text/javascript"/>
```


