function formatDateTime(fmt, date) {
    var o = {
        "M+": date.getMonth() + 1, //月份
        "d+": date.getDate(), //日
        "H+": date.getHours(), //小时
        "m+": date.getMinutes(), //分
        "s+": date.getSeconds(), //秒
        "q+": Math.floor((date.getMonth() + 3) / 3), //季度
        "S": date.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}


$(function () {
    new Vue({
        el: '#app',
        data: function () {
            var now = new Date();
            var oneHourAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
            return {
                bizID: '',
                bizList: [
                    {"bk_biz_id":2, "bk_biz_name":"蓝鲸"},
                    {"bk_biz_id":3, "bk_biz_name":"测试业务",}],
                setID: '',
                setList: [
                    {"bk_set_id":1, "bk_set_name": "set1"},
                    {"bk_set_id":2, "bk_set_name": "set2"},
                    {"bk_set_id":3, "bk_set_name": "set3"}
                            ],
                moduleID: '',
                moduleList: [
                    {"bk_module_id":1, "bk_module_name": "module1"},
                    {"bk_module_id":2, "bk_module_name": "module2"},
                    {"bk_module_id":3, "bk_module_name": "module3"}
                            ],
                statusID: '',
                statusList: [
                    {"key": "ALL", "display_name":"全部"},
                    {"key": "PENDING", "display_name":"待处理"},
                    {"key": "RUNNING", "display_name":"执行中"},
                    {"key": "SUSPENDED", "display_name":"暂停"},
                    {"key": "FINISHED", "display_name":"已完成"},
                    {"key": "FAILED", "display_name":"失败"},
                    {"key": "TIMEOUT", "display_name":"超时未处理"}],
                queryDatetimeRange: [oneHourAgo, now],
                alarmsData: [
                    {
                        "id": 3,
                        "bk_biz_id": 2,
                        "bk_module_id": "34,38,39,40,49",
                        "bk_set_id": "8,9",
                        "operator": "",
                        "bk_inner_ip": "192.168.0.1",
                        "source_time": "2020-02-06 20:39:00",
                        "status": "待处理",
                        "bk_sops_task_url": "http://exam.pass.tencent.com/o/bk_sops/taskflow/execute/2/?instance_id=73"
                    },
                    {
                        "id": 2,
                        "bk_biz_id": 2,
                        "bk_module_id": "34,38,39,40,49",
                        "bk_set_id": "8,9",
                        "operator": "admin",
                        "bk_inner_ip": "192.168.0.1",
                        "source_time": "2020-02-06 20:14:00",
                        "status": "已完成",
                        "bk_sops_task_url": "http://exam.pass.tencent.como/bk_sops/taskflow/execute/2/?instance_id=72"
                    },
                    {
                        "id": 1,
                        "bk_biz_id": 2,
                        "bk_module_id": "34,38,39,40,49",
                        "bk_set_id": "8,9",
                        "operator": "admin",
                        "bk_inner_ip": "192.168.0.4",
                        "source_time": "2020-02-06 11:44:00",
                        "status": "已完成",
                        "bk_sops_task_url": "http://exam.pass.tencent.com/o/bk_sops/taskflow/execute/2/?instance_id=71"
                    },
                    {
                        "id": 1,
                        "bk_biz_id": 2,
                        "bk_module_id": "34,38,39,40,49",
                        "bk_set_id": "8,9",
                        "operator": "admin",
                        "bk_inner_ip": "192.168.0.3",
                        "source_time": "2020-02-06 11:44:00",
                        "status": "处理中",
                        "bk_sops_task_url": "http://exam.pass.tencent.com/o/bk_sops/taskflow/execute/2/?instance_id=70"
                    },
                    {
                        "id": 1,
                        "bk_biz_id": 2,
                        "bk_module_id": "34,38,39,40,49",
                        "bk_set_id": "8,9",
                        "operator": "",
                        "bk_inner_ip": "192.168.0.2",
                        "source_time": "2020-02-06 11:44:00",
                        "status": "超时未处理",
                        "bk_sops_task_url": ""
                    }
                ]
,
                timeSeries: []
            }
        },
        methods: {

            refreshAlarmsData: function () {
                //TODO
            },
            exportAlarmsData: function () {
                //TODO
            },


            setChanged: function (value, option) {
                //TODO
            },
            release: function (value, option) {
                //TODO

            },
            releaseDetail: function (value, option) {
                window.open(value.bk_sops_task_url);
            },
        },

        mounted: function () {
            var self = this;
            // TODO
        }
    })
})

