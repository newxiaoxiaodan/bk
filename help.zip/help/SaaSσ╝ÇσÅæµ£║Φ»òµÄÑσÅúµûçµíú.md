# 接口文档



**重要说明：请认真阅读以下规范，功能实现且符合规范的接口将酌情加分**



## 接口规范

### 1. 接口请求规范

- GET 请求，请使用 **查询字符串** 进行传参，如 `http://test.bk.com/sets/?bk_biz_id=2`

- POST 请求，请使用 **JSON** 格式进行传参，以下是使用 jquery 发起 post ajax 请求的例子

  ```js
  $.ajax({
      type: "post",
      url: site_url + 'release/',
      data: JSON.stringify({
          bk_biz_id: 2
      }),
      contentType: "application/json",
      dataType: "json",
      success: function(result) {}
  })
  ```

- 必须严格按照接口文档规定的请求方法 (GET/POST) 进行接口请求

### 2. 接口返回规范

- 必须使用 **JSON** 格式返回数据
- 接口返回状态码必须为 **200**
- 返回格式，包括数据类型、数据结构等，必须与接口文档保持一致



## [API-01] 获取集群列表

- 请求方法及URL

```
GET /sets/
```

- 请求参数示例

```json
?bk_biz_id=2
```

- 请求参数说明

| 字段      | 类型 | 必选 | 描述   |
| :-------- | ---- | ---- | ------ |
| bk_biz_id | int  | 是   | 业务id |


- 返回结果示例

```json
{
    "result": true,
    "code": 0,
    "data": [
        {
            "bk_set_id": 9,
            "bk_set_name": "作业平台"
        },
        {
            "bk_biz_id": 5,
            "bk_biz_name": "故障自愈"
        }
        ...
    ],
    "message": "OK"
}
```

- 返回结果参数说明

| 字段    | 类型   | 描述                              |
| ------- | ------ | --------------------------------- |
| result  | bool   | 返回结果，true为成功，false为失败 |
| code    | int    | 返回码，0表示成功，其他值表示失败 |
| message | string | 错误信息                          |
| data    | list   | 结果                              |

data

| 字段        | 类型   | 描述     |
| ----------- | ------ | -------- |
| bk_set_id   | int    | 集群ID   |
| bk_set_name | string | 集群名称 |



## [API-02] 获取模块列表

- 请求方法及URL

```
GET /modules/
```

- 请求参数示例

```json
??bk_set_id=3&bk_biz_id=2
```

- 请求参数说明

| 字段      | 类型 | 必选 | 描述   |
| :-------- | ---- | ---- | ------ |
| bk_biz_id | int  | 是   | 业务id |
| bk_set_id | int  | 是   | 集群id |

- 返回结果示例

```json
{
    "message": "OK",
    "code": 0,
    "data": [
        {
			bk_module_name: "proccontroller",
			bk_module_id: 5
		},
		{
			bk_module_name: "procserver",
			bk_module_id: 6
		},
		...
    ],
    "result": true
}
```

- 返回结果参数说明

| 字段    | 类型   | 描述                              |
| ------- | ------ | --------------------------------- |
| result  | bool   | 返回结果，true为成功，false为失败 |
| code    | int    | 返回码，0表示成功，其他值表示失败 |
| message | string | 错误信息                          |
| data    | list   | 结果                              |

data

| 字段        | 类型   | 描述         |
| ----------- | ------ | ------------ |
| bk_module_name| string | 模块ID       |
| bk_module_id  | int   | 模块名称 |



## [API-04] 获取告警列表
- 请求方法及URL

```
GET /alarms/
```
- 请求参数示例

```json
bk_set_id=3&bk_module_id=9&status=TIMEOUT&source_time__gte=2020-11-30 17:08:14&source_time__lte=2020-12-01 17:08:14
```

- 请求参数说明

| 字段        | 类型   | 必选 | 描述                   |
| :---------- | ------ | ---- | ---------------------- |
| bk\_set_id   | int    | 否   |   对应的set集群 ID，如果一台机器对应多个，可以用bk\_set\_id__contains来实现  |
| bk\_module_id   | int    | 否   |   对应的模块 ID，如果一台机器对应多个，可以用bk_module_id__contains来实现  |
| status   | string    | 否   |   任务的状态  |
| source\_time__gte   | string    | 否   |   告警发生时间查询起始点  |
| source\_time__lte   | string    | 否   |   告警发生时间查询结束点  |

- 返回参数示例

```json
{
	"result":true,
	 "code": 0,
	"message": "OK",
	   "data": [
	    {
	        "id": 3,
	        "bk_biz_id": 2,
	        "cc_app_module": ",5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,24,",
	        "cc_topo_set": ",3,4,7,8,",
	        "operator": "",
	        "bk_inner_ip": "10.0.0.15",
	        "source_time": "2020-11-30 20:27:00",
	        "status": "处理超时",
	        "bk_sops_task_url": "",
	        "bk_set_id": "3,4,7,8",
	        "bk_module_id": "18,24,22,25,9,5,48,42,12,8,28,55,26,40,35,57,10"
	    },
	   {
	        "id": 1,
	        "bk_biz_id": 2,
	        "operator": "admin",
	        "bk_inner_ip": "127.0.0.1",
	        "source_time": "2020-11-30 20:19:00",
	        "status": "处理超时",
	        "bk_sops_task_url": "http://paas.exam.bktencent.com:80/o/bk_sops/taskflow/execute/2/?instance_id=3",
	        "bk_set_id": "3,4,7,8",
	        "bk_module_id": "18,24,22,25,9,5,48,42,12,8,28,55,26,40,35,57,10,"
	    }
	]
}
```

| 字段    | 类型   | 描述                              |
| ------- | ------ | --------------------------------- |
| result  | bool   | 返回结果，true为成功，false为失败 |
| code    | int    | 返回码，0表示成功，其他值表示失败 |
| message | string | 错误信息                          |
| data    | list   | 结果 (具体参数根据表结构设计返回，示例见上图返回数据)     |



## [API-05] 重启进程
- 请求方法及URL

```
POST /alarms/{alarm_id}/release
```

- 请求参数示例

```json
{
}
```

- 路径参数说明

| 字段        | 类型   | 必选 | 描述                   |
| :---------- | ------ | ---- | ---------------------- |
| alarm_id   | int    | 是   |   对应的告警ID  |

- 返回结果示例

正常返回

```json
//成功
{
    "message": "OK",
    "code": "0",
    "data": {“task_url”:"http://{host}/o/sops/xxx"},
    "result": true
}
//失败
{
    "message": "error message of release",
    "code": "0",
    "data": {},
    "result": false
}
```

- 返回结果参数说明

| 字段    | 类型   | 描述                              |
| ------- | ------ | --------------------------------- |
| result  | bool   | 返回结果，true为成功，false为失败 |
| code    | int    | 返回码，0表示成功，其他值表示失败 |
| message | string | 错误信息                          |
| data    | list   | 结果                              |

data

| 字段    | 类型 | 描述             |
| ------- | ---- | ---------------- |
| task_url | string  | 生成的标准运维任务链接 |

另外，若当前告警存在正在执行的任务，即处于 CREATED, RUNNING, SUSPENDED 这三种任务状态的其中一种时。则直接返回报错，不重复执行任务。
```json
{
    "message": "创建发布任务失败：当前主机存在未完成的任务",
    "code": 5501001,
    "data": null,
    "result": false
}
```



## [API-06] 导出数据接口

- 请求方法及URL

```
GET /export/
```

- 请求参数示例

```json
bk_set_id=3&bk_module_id=9&status=TIMEOUT&source_time__gte=2020-11-30 17:08:14&source_time__lte=2020-12-01 17:08:14
```

- 请求参数说明

| 字段        | 类型   | 必选 | 描述                   |
| :---------- | ------ | ---- | ---------------------- |
| bk\_set_id   | int    | 否   |   对应的set集群 ID，如果一台机器对应多个，可以用bk\_set\_id__contains来实现  |
| bk\_module_id   | int    | 否   |   对应的模块 ID，如果一台机器对应多个，可以用bk_module_id__contains来实现  |
| status   | string    | 否   |   任务的状态  |
| source\_time__gte   | string    | 否   |   告警发生时间查询起始点  |
| source\_time__lte   | string    | 否   |   告警发生时间查询结束点  |


- 返回结果示例为excel文档
             